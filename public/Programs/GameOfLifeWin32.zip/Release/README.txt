--- Game of Life Win 32 by Austin Bray ---

Use the .config file to change the settings of the simulation

CellAmount controls the amount of cells to be randomly placed
GridSize controls the size of the grid
UpdateSpeed controls the update speed of the simulation (in milliseconds, must be >= 10)

Use S to start the simulation
Use R to restart the simulation